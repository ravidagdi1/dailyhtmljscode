function hanldetime(){

let a=new Date()

let currentDate=a.getDate()

let currentMonth=a.getMonth()+1

let currentYear=a.getFullYear()

let currentHours=a.getHours()
let currentMins=a.getMinutes()
let currentSecond=a.getSeconds()


console.log(currentDate+'-'+currentMonth+'-'+currentYear+' '+currentHours+':'+currentMins+':'+currentSecond)
console.log(a)
let x=document.getElementById('output').innerText = 'Current Date & Time: '+currentDate+'-'+currentMonth+'-'+currentYear+' '+currentHours+':'+currentMins+':'+currentSecond
}
setInterval(hanldetime,1000*1)


//dd-mm-yyyy h:m:s

//currentDate+'-'+currentMonth+'-'+currentYear+' '+currentHours+':'+currentMins+':'+currentSecond